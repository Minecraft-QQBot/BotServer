from .Base import *
from .List import *
from .Append import *
from .Remove import *

from nonebot.log import logger

logger.debug('命令加载 Bound 完毕！')
